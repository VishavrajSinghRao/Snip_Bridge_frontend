// DatasetManagement.jsx
import React from 'react';

const DatasetManagement = () => {
  return (
    <div className="page-container">
      <h2 className="page-title">Dataset Management</h2>
      <p>This is a placeholder for managing datasets.</p>
    </div>
  );
};

export default DatasetManagement;
